// Assignment DAA LAB
// Question 1
// Saharsh Ananta Jaiswal
// 18CS8061

// ------------------Priority Queue using Heap  ----------------------

/* 

Priority Queue is a type of queuu in which every element has a key associated to it and the queue returns the lement according to these keys unlike the tradiontal queue hcih wworks on first come first serve basis

Thus , a max-priority queue returns the element with maximum key first whereas, a min-priority queue returns the element with the smallest key first.


Heaps are  great for implementing a priorty queue because of the largest and smallest element at the root of the tree